<?php if('version.php' == basename($_SERVER['SCRIPT_FILENAME'])) 
     die('<h2>Direct File Access Prohibited</h2>'); 
############################################################
// Version file by Mike Cherim @ http://green-beast.com
############################################################

    $version = "v3";
    $buildno = "B3.20090130.01";
    $modelno = "SASU";
    $verskey = "JwstR4ee239kLx";

############################################################
// EOF - Mike Cherim @ http://green-beast.com
############################################################
?>